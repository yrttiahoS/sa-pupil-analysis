function [colcount] = columnCount(DATA)
%Function [colcount] = columnCount(DATA)
%
% Returns the count of columns in DATA

colcount = length(DATA);